#!/usr/bin/env bash
# Generate the XHTTP path (if missing) and render the Remnawave config profile,
# Host reference, and node nginx config from templates into build/.
#
# Users and UUIDs are managed by the Remnawave panel, not here.
#
# Usage:
#   scripts/setup.sh                      # generate path (if needed) + render
#   scripts/setup.sh --self-signed-cert   # also create a self-signed origin cert
set -euo pipefail

cd "$(dirname "$0")/.."

GEN_CERT=0
[[ "${1:-}" == "--self-signed-cert" ]] && GEN_CERT=1

# --- 1. Ensure .env exists -------------------------------------------------
if [[ ! -f .env ]]; then
  echo "==> .env not found; creating it from .env.example"
  cp .env.example .env
fi

# --- 2. Load .env ----------------------------------------------------------
set -a; . ./.env; set +a

# --- helpers ---------------------------------------------------------------
gen_path() { echo "/$(openssl rand -hex 8)"; }

set_env() { # set_env KEY VALUE  — update or append KEY=VALUE in .env
  local key="$1" val="$2"
  if grep -qE "^${key}=" .env; then
    sed -i "s|^${key}=.*|${key}=${val}|" .env
  else
    printf '%s=%s\n' "$key" "$val" >> .env
  fi
}

# --- 3. Generate the XHTTP path if it is missing ---------------------------
if [[ -z "${XRAY_PATH:-}" ]]; then
  XRAY_PATH="$(gen_path)"; set_env XRAY_PATH "$XRAY_PATH"
  echo "==> generated XRAY_PATH=$XRAY_PATH"
fi

# Defaults for optional vars (in case an older .env predates them).
: "${XRAY_MODE:=packet-up}"
: "${XRAY_LISTEN:=127.0.0.1}"
: "${XRAY_BACKEND_HOST:=127.0.0.1}"
: "${INBOUND_TAG:=VLESS_XHTTP}"
: "${HOST_REMARK:=xhttp-cdn}"
: "${ORIGIN_DOMAIN:=}"

# --- 4. Sanity checks ------------------------------------------------------
if [[ -z "${XRAY_DOMAIN:-}" || "${XRAY_DOMAIN}" == "cdn.example.com" ]]; then
  echo "!!! XRAY_DOMAIN is still the placeholder. Set it in .env to your public" >&2
  echo "    CDN hostname and re-run 'make setup'." >&2
fi
if [[ -z "${ORIGIN_DOMAIN:-}" || "${ORIGIN_DOMAIN}" == "node.example.com" ]]; then
  echo "!!! ORIGIN_DOMAIN is still the placeholder. Set it in .env to the node" >&2
  echo "    hostname the CDN connects back to and re-run 'make setup'." >&2
fi

# --- 5. Render templates ---------------------------------------------------
render() { # render SRC DST
  local src="$1" dst="$2"
  mkdir -p "$(dirname "$dst")"
  sed -e "s|@@XRAY_DOMAIN@@|${XRAY_DOMAIN}|g" \
      -e "s|@@ORIGIN_DOMAIN@@|${ORIGIN_DOMAIN}|g" \
      -e "s|@@XRAY_PATH@@|${XRAY_PATH}|g" \
      -e "s|@@XRAY_MODE@@|${XRAY_MODE}|g" \
      -e "s|@@XRAY_LISTEN@@|${XRAY_LISTEN}|g" \
      -e "s|@@XRAY_BACKEND_HOST@@|${XRAY_BACKEND_HOST}|g" \
      -e "s|@@INBOUND_TAG@@|${INBOUND_TAG}|g" \
      -e "s|@@HOST_REMARK@@|${HOST_REMARK}|g" \
      "$src" > "$dst"
  echo "==> rendered $dst"
}

render remnawave/config-profile.json.template  build/remnawave/config-profile.json
render remnawave/host.reference.json.template   build/remnawave/host.reference.json
render server/nginx/default.conf.template       build/server/nginx/default.conf

# --- 6. Validate the JSON we produced -------------------------------------
if command -v jq >/dev/null 2>&1; then
  for f in build/remnawave/config-profile.json build/remnawave/host.reference.json; do
    jq empty "$f" && echo "==> valid JSON: $f"
  done
fi

# --- 7. Optional self-signed cert -----------------------------------------
if [[ "$GEN_CERT" == "1" ]]; then
  mkdir -p server/nginx/certs
  if [[ -s server/nginx/certs/origin.crt ]]; then
    echo "==> origin cert already present; leaving it in place"
  else
    cn="${ORIGIN_DOMAIN:-localhost}"
    echo "==> generating self-signed origin cert for ${cn}"
    openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
      -keyout server/nginx/certs/origin.key \
      -out    server/nginx/certs/origin.crt \
      -subj   "/CN=${cn}" \
      -addext "subjectAltName=DNS:${cn}"
  fi
fi

echo
echo "==> Done. Rendered files are in build/:"
echo "    - build/remnawave/config-profile.json  -> import as a Config Profile"
echo "    - build/remnawave/host.reference.json   -> values for the panel Host"
echo "    - build/server/nginx/default.conf       -> node nginx (then 'make up')"
echo "    Print the Host values any time with 'make host'."
