#!/usr/bin/env bash
# Print the Remnawave Host field values to set in the panel (Hosts -> Create)
# for the VLESS-XHTTP inbound exposed through the CDN.
set -euo pipefail

cd "$(dirname "$0")/.."

if [[ ! -f .env ]]; then
  echo "Run 'make setup' first (no .env found)." >&2
  exit 1
fi

set -a; . ./.env; set +a
: "${XRAY_MODE:=packet-up}"
: "${INBOUND_TAG:=VLESS_XHTTP}"
: "${HOST_REMARK:=xhttp-cdn}"

if [[ -z "${XRAY_DOMAIN:-}" || -z "${XRAY_PATH:-}" ]]; then
  echo "XRAY_DOMAIN and XRAY_PATH must be set (run 'make setup')." >&2
  exit 1
fi

cat <<EOF
Remnawave Host — set these in the panel (Hosts -> Create):

  Remark         : ${HOST_REMARK}
  Inbound        : ${INBOUND_TAG}   (from the imported config profile)
  Address        : ${XRAY_DOMAIN}
  Port           : 443
  Security       : tls
  SNI            : ${XRAY_DOMAIN}
  Host           : ${XRAY_DOMAIN}
  Path           : ${XRAY_PATH}
  Network / Type : xhttp
  XHTTP mode     : ${XRAY_MODE}
  ALPN           : h2, http/1.1
  Fingerprint    : chrome
  Allow Insecure : off

Clients/UUIDs and the subscription link are issued by the panel per user.
Reference copy: build/remnawave/host.reference.json
EOF
