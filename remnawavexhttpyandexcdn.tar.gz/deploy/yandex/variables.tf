variable "cloud_id" {
  type        = string
  description = "Yandex Cloud cloud ID."
}

variable "folder_id" {
  type        = string
  description = "Yandex Cloud folder ID."
}

variable "resource_name" {
  type        = string
  description = "Name prefix for the CDN origin group / resource."
  default     = "xhttp-cdn"
}

variable "cdn_domain" {
  type        = string
  description = "Public hostname clients connect to (matches XRAY_DOMAIN in .env)."
}

variable "origin_domain" {
  type        = string
  description = "Remnawave node hostname the CDN connects to over HTTPS (matches ORIGIN_DOMAIN)."
}

variable "origin_port" {
  type        = number
  description = "Origin HTTPS port (matches ORIGIN_HTTPS_PORT)."
  default     = 443
}

# Only needed if you switch the ssl_certificate block to certificate_manager.
# variable "certificate_id" {
#   type        = string
#   description = "Certificate Manager certificate ID for cdn_domain."
#   default     = null
# }
