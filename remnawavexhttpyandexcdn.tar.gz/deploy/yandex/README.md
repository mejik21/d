# Terraform: Yandex Cloud CDN for the XHTTP origin

Provisions the CDN side of the setup — an **origin group** pointing at your
origin and a **CDN resource** with caching disabled and `POST` allowed, so the
Xray XHTTP tunnel works through it.

## Use

```bash
cd deploy/yandex
cp terraform.tfvars.example terraform.tfvars
$EDITOR terraform.tfvars        # cloud_id, folder_id, cdn_domain, origin_domain

# Authenticate the provider (either works):
#   yc init                     # interactive yc CLI profile, or
#   export YC_TOKEN=$(yc iam create-token)

terraform init
terraform plan                  # review before applying
terraform apply
```

After apply, Terraform prints `dns_cname_target`. Create a DNS **CNAME** from
`cdn_domain` to that value, and keep an **A** record for `origin_domain`
pointing at the Remnawave node. The edge certificate can take up to ~30 minutes
to activate.

## Notes

- **Certificate:** defaults to `ssl_certificate { type = "lets_encrypt_gcore" }`
  (CDN-managed Let's Encrypt for `cdn_domain`). If your provider version rejects
  it or you already manage the cert in Certificate Manager, switch to the
  commented `certificate_manager` block in `main.tf` and set `certificate_id`.
  Always run `terraform plan` first and adjust to your provider version —
  pin `version` in `main.tf` if needed.
- **Origin certificate** (for `origin_domain`, on the node nginx) is separate
  and not managed here — see `../../server/nginx/certs/README.md`.
- Field names follow the
  [`yandex_cdn_resource`](https://registry.terraform.io/providers/yandex-cloud/yandex/latest/docs/resources/cdn_resource)
  provider docs.
