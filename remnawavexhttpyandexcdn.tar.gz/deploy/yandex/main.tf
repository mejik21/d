# Yandex Cloud CDN resource that fronts the Xray XHTTP origin.
#
#   client -> CDN resource (cname) -> origin group (ORIGIN_DOMAIN:443, HTTPS)
#          -> nginx -> Xray
#
# Authenticate the provider with the `yc` CLI (`yc init`) or a service-account
# key; cloud_id / folder_id come from variables. See terraform.tfvars.example.

terraform {
  required_version = ">= 1.0"
  required_providers {
    yandex = {
      source  = "yandex-cloud/yandex"
      version = ">= 0.100"
    }
  }
}

provider "yandex" {
  cloud_id  = var.cloud_id
  folder_id = var.folder_id
  # token or service_account_key_file are read from the environment / yc profile.
}

resource "yandex_cdn_origin_group" "xhttp" {
  name = "${var.resource_name}-origins"

  origin {
    source  = "${var.origin_domain}:${var.origin_port}"
    enabled = true
  }
}

resource "yandex_cdn_resource" "xhttp" {
  cname           = var.cdn_domain
  active          = true
  origin_protocol = "https"
  origin_group_id = yandex_cdn_origin_group.xhttp.id

  # Visitor-facing TLS. "lets_encrypt_gcore" lets the CDN issue and renew a
  # Let's Encrypt certificate for cdn_domain automatically. If `terraform plan`
  # rejects this on your provider version, or you already manage the cert,
  # comment this block and use the certificate_manager block below instead.
  ssl_certificate {
    type = "lets_encrypt_gcore"
  }
  # ssl_certificate {
  #   type                   = "certificate_manager"
  #   certificate_manager_id = var.certificate_id
  # }

  options {
    # The tunnel is dynamic: never cache it.
    disable_cache = true

    # packet-up carries the upload direction over POST — it must be allowed.
    allowed_http_methods = ["GET", "POST", "HEAD", "OPTIONS"]

    # Forward query strings unchanged.
    ignore_query_params = false

    # Send the origin's own hostname so it matches the origin TLS certificate.
    # (The Xray server accepts any Host, so this is about the HTTPS hop only.)
    forward_host_header = false
    custom_host_header  = var.origin_domain
  }
}

output "dns_cname_target" {
  description = "Create a DNS CNAME: cdn_domain -> this value."
  value       = yandex_cdn_resource.xhttp.provider_cname
}
