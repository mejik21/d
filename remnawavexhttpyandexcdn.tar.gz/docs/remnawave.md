# Wiring this into Remnawave

This repo provides the transport infrastructure; [Remnawave](https://remna.st/)
provides the panel that manages users, hosts and subscriptions. Here is how the
two fit together for a VLESS-XHTTP inbound fronted by Yandex Cloud CDN.

## Roles

- **Panel** — the control plane. Stores users, issues UUIDs, renders
  subscriptions, and pushes config profiles to nodes. Runs on its own host.
- **Node** (`remnawave-node`) — runs Xray from the assigned config profile. In
  this setup the node's Xray listens for the XHTTP inbound on `127.0.0.1:8001`
  and does **not** own port 443.
- **This repo, on the node** — the nginx that terminates the CDN's TLS on 443,
  serves a decoy at `/`, and forwards the secret path to the inbound; plus the
  config profile and Host values you load into the panel.

## 0. Install Remnawave

Install the panel and a node per the official docs (<https://remna.st/>). Bring
the node online and confirm it shows as connected in the panel **before** adding
the inbound. The node uses host networking, so the loopback inbound and nginx
share the host's network namespace.

## 1. Render the artifacts (on the node)

```bash
cp .env.example .env
$EDITOR .env                 # XRAY_DOMAIN (CDN) + ORIGIN_DOMAIN (node)
make setup
```

This writes:

- `build/remnawave/config-profile.json` — the Xray config profile.
- `build/remnawave/host.reference.json` — the Host field values.
- `build/server/nginx/default.conf` — the node nginx config.

## 2. Create the Config Profile

In the panel: **Config Profiles → Create**, and import
`build/remnawave/config-profile.json`. It contains one inbound:

- **tag** `VLESS_XHTTP` (this is how the Host links to it),
- `network: xhttp`, `security: none` (TLS is terminated by nginx in front),
- `path` and `mode` already filled from your `.env`,
- `clients: []` — the panel injects users automatically; do not add UUIDs here.

Assign the profile to your node and let it apply. The node's Xray will start
listening on `127.0.0.1:8001`.

## 3. Bring up the node nginx + decoy

Provide a certificate for `ORIGIN_DOMAIN` (see
[`../server/nginx/certs/README.md`](../server/nginx/certs/README.md)), then:

```bash
make up        # nginx (host networking) on :443 -> 127.0.0.1:8001
make logs
```

nginx must own port 443 on the node. If the node was set up with a Reality
"selfsteal" listener on 443, disable it — this XHTTP setup puts nginx in front.

## 4. Put the node behind Yandex Cloud CDN

Provision the CDN resource + origin group so the edge (`XRAY_DOMAIN`) forwards to
the node (`ORIGIN_DOMAIN:443`) with caching disabled and `POST` allowed — use the
Terraform in [`../deploy/yandex/`](../deploy/yandex/) or the walkthrough in
[yandex-cdn.md](yandex-cdn.md). Then CNAME `XRAY_DOMAIN` at the CDN.

## 5. Create the Host

In the panel: **Hosts → Create**. Run `make host` and copy the values:

| Field          | Value                         |
|----------------|-------------------------------|
| Remark         | `HOST_REMARK` (e.g. xhttp-cdn)|
| Inbound        | `VLESS_XHTTP`                 |
| Address        | `XRAY_DOMAIN`                 |
| Port           | `443`                         |
| Security       | `tls`                         |
| SNI            | `XRAY_DOMAIN`                 |
| Host           | `XRAY_DOMAIN`                 |
| Path           | `XRAY_PATH`                   |
| Network / Type | `xhttp`                       |
| XHTTP mode     | `XRAY_MODE` (packet-up)       |
| ALPN           | `h2, http/1.1`                |
| Fingerprint    | `chrome`                      |
| Allow Insecure | off                           |

The **Address/SNI/Host are the CDN domain** (`XRAY_DOMAIN`), not the node — the
client connects to the CDN edge, which presents the CDN-managed certificate. The
**Path and XHTTP mode must match the inbound** exactly, or nginx will hand the
request to the decoy instead of the tunnel.

## 6. Hand out subscriptions

Assign users to the inbound/host in the panel. Each user gets a subscription URL
that resolves to a `vless://` entry built from the Host above. Because UUIDs are
per-user and managed by the panel, this repo never sees them — rotate or revoke
users entirely in Remnawave.

## Sanity checks

- Node shows **connected** in the panel and the profile is **applied**.
- `curl -I https://ORIGIN_DOMAIN/` returns the decoy (then lock the firewall to
  the CDN).
- `curl -I https://XRAY_DOMAIN/` returns the decoy **through the CDN**.
- A user's subscription imports and connects; traffic egresses from the node.
