# Putting the origin behind Yandex Cloud CDN

Yandex Cloud CDN is a pull CDN: you define an **origin group** (where the real
content lives) and a **CDN resource** (the public edge). Clients hit the
resource; the resource fetches from the origin group over HTTP or HTTPS.

This is the manual console/CLI walkthrough. For a reproducible version, use the
Terraform in [`../deploy/yandex/`](../deploy/yandex/) — it creates the same
origin group and resource with the right options.

## 0. Names and certificates

| Name           | Role                                | TLS certificate                         |
|----------------|-------------------------------------|-----------------------------------------|
| `XRAY_DOMAIN`  | public hostname clients connect to  | issued by the CDN (managed Let's Encrypt)|
| `ORIGIN_DOMAIN`| the Remnawave node the CDN pulls from| yours, on the node nginx                |

Give the Remnawave node its own DNS `A` record for `ORIGIN_DOMAIN` and a
certificate valid for it (see `../server/nginx/certs/README.md`). Bring the node
nginx up first (`make setup && make up`, with the config profile applied) so the
CDN has something to pull from.

## 1. Create the origin group

Console: **Cloud CDN → Origin groups → Create**, add one origin with
**Source** `ORIGIN_DOMAIN` and port `443`, enabled.

CLI:

```bash
yc cdn origin-group create \
  --name xhttp-origins \
  --origin source=node.example.com:443,enabled=true
```

Note the printed origin group ID.

## 2. Create the CDN resource

Console: **Cloud CDN → CDN resources → Create**, then:

- **Content query domain (cname)**: `XRAY_DOMAIN`.
- **Origin group**: the one from step 1.
- **Protocol for origins**: **HTTPS** (the CDN connects to `ORIGIN_DOMAIN:443`).
- **Certificate type**: **Let's Encrypt** — the CDN issues and renews the
  visitor-facing cert for `XRAY_DOMAIN` (can take up to ~30 min to activate).
  Alternatively pick a **Certificate Manager** certificate you already own.

CLI:

```bash
yc cdn resource create \
  --cname cdn.example.com \
  --origin-group-id <ORIGIN_GROUP_ID> \
  --origin-protocol https \
  --cert-manager-self-managed-... # or configure Let's Encrypt in the console
```

> Certificate provisioning is easiest in the console or via Terraform
> (`ssl_certificate { type = "lets_encrypt_gcore" }`). See `deploy/yandex/`.

## 3. Set the resource options (critical for XHTTP)

The tunnel is dynamic, so the CDN must not cache it and must forward `POST`:

- **Caching**: **disabled** (`disable_cache = true`). The XHTTP path must never
  be served from cache.
- **Allowed HTTP methods**: include **`GET`, `POST`, `HEAD`, `OPTIONS`**. POST
  carries the upload direction in `packet-up` mode; if it is not allowed the
  tunnel cannot send data.
- **Host header**: send the origin's host header so it matches the origin
  certificate (`forward_host_header = false`, `custom_host_header =
  ORIGIN_DOMAIN`). The Xray server accepts any Host, so either host-header
  policy works, but matching the origin cert keeps the HTTPS hop clean.
- **Query strings**: forward them (do not ignore query params).

CLI (options are set with `yc cdn resource update --options ...`; the field
names mirror the Terraform `options` block):

```bash
yc cdn resource update <RESOURCE_ID> \
  --options disable-cache=true \
  --options allowed-http-methods=GET,POST,HEAD,OPTIONS \
  --options forward-host-header=false \
  --options custom-host-header=node.example.com
```

## 4. DNS

The resource has a provider CNAME target (something like `cl-….edgecdn.ru`,
shown in the console / `provider_cname` Terraform output). Point your public
hostname at it:

```
Type   Name              Value
CNAME  cdn.example.com   cl-xxxxxxxx.edgecdn.ru.
```

Keep the separate `A` record for `ORIGIN_DOMAIN` pointing at the origin IP.

## 5. Lock the node to the CDN

`ORIGIN_DOMAIN` exposes the node IP in DNS, so restrict who can reach the node's
`:443` to **Yandex Cloud CDN egress ranges** (plus your own admin IP). With that
firewall in place the node only answers the CDN, even though its address is
public.

## 6. Verify

After the edge certificate activates and DNS propagates:

```bash
# Decoy site should load through the CDN:
curl -I https://cdn.example.com/

# Origin reachable directly (for your own check; lock this down afterwards):
curl -I https://node.example.com/
```

Then `make link`, import into your client, and browse through the local SOCKS
proxy on `127.0.0.1:1080`.

## Notes & limits

- **5-second origin timeout:** the origin must start responding within 5s or the
  CDN returns `504`. Xray answers immediately and `packet-up` keeps requests
  short, so this is fine in practice — but it rules out the long-lived
  `stream-up` / `stream-one` modes.
- **Response buffering:** Yandex Cloud CDN is tuned for static content. If the
  download direction feels buffered or stalls, confirm caching is disabled, and
  as an advanced option consider XHTTP `downloadSettings` to pull the download
  channel from the origin directly while uploads go through the CDN.
- **No WebSocket/gRPC needed:** XHTTP is plain HTTP, so you only need `GET`/`POST`
  allowed and caching off — nothing protocol-specific to enable.
