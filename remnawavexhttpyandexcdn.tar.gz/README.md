# Xray XHTTP for Remnawave, behind Yandex Cloud CDN

Infrastructure companion for a [Remnawave](https://remna.st/) deployment: it
provides the **node-side Xray config profile** (VLESS over the XHTTP transport),
the **nginx reverse proxy + decoy** that fronts it, and the **Yandex Cloud CDN**
in front of that — plus the **Host** values that expose it to clients.

The Remnawave **panel** owns users, UUIDs, hosts and subscriptions. This repo
only provides the proxy/transport infrastructure the panel and its node drive.

> Intended for legitimate uses: privacy, secure remote access, and reaching the
> open internet from restrictive networks. Run it only on infrastructure you
> control and are authorised to use.

## Architecture

```
   client (gets a subscription from the panel)
        │  vless:// xhttp + tls
        ▼
   ┌─────────────────────────┐
   │   Yandex Cloud CDN edge  │   cname = XRAY_DOMAIN, CDN-managed cert
   └────────────┬────────────┘
                │  HTTPS to origin group (ORIGIN_DOMAIN:443)
                ▼
   ┌──────────────────────────────────────────────┐
   │  Remnawave NODE host                          │
   │   nginx :443   "/"        → decoy site         │
   │                "/<path>"  → 127.0.0.1:8001 ───┐│
   │   Xray (remnawave-node)  VLESS-XHTTP inbound  ◄┘│  on 127.0.0.1:8001
   └───────────────────────▲──────────────────────┘
                           │ config profile pushed by
                ┌──────────┴───────────┐
                │   Remnawave PANEL     │  users · hosts · subscriptions
                └──────────────────────┘
```

| Component        | Who runs it          | This repo provides                         |
|------------------|----------------------|--------------------------------------------|
| Panel            | you (separate host)  | —  (manages users/hosts/subscriptions)     |
| Node (Xray)      | remnawave-node       | the **config profile** it runs             |
| Node nginx+decoy | you (on the node)    | nginx config, decoy site, Compose stack    |
| CDN              | Yandex Cloud         | Terraform for the resource + origin group  |
| Client Host      | panel                | the **Host reference** values to enter      |

Two hostnames: **`XRAY_DOMAIN`** is the CDN edge clients connect to (CDN-managed
certificate); **`ORIGIN_DOMAIN`** is the node's own name + certificate that the
CDN connects back to over HTTPS.

## Why XHTTP + `packet-up` here

XHTTP carries the tunnel inside ordinary HTTP requests, so a CDN proxies it
happily — and unlike Reality "selfsteal", it can sit *behind* a CDN. Yandex
Cloud CDN enforces a **5-second origin-response timeout** and buffers responses,
so the long-lived `stream-*` modes don't survive; **`packet-up`** (short POSTs)
is the reliable choice and the default. The same mode value must be set on the
config-profile inbound **and** the Host.

## Repository layout

```
.
├── remnawave/
│   ├── config-profile.json.template   # Xray config profile (VLESS-XHTTP inbound)
│   └── host.reference.json.template    # Host field values for the panel
├── server/
│   ├── nginx/default.conf.template     # node nginx: CDN TLS + path -> inbound + decoy
│   ├── nginx/certs/                    # drop origin.crt / origin.key here
│   └── www/index.html                  # decoy landing page
├── deploy/yandex/                      # Terraform: CDN resource + origin group
├── scripts/
│   ├── setup.sh                        # render templates -> build/ (panel owns UUIDs)
│   └── host-values.sh                  # print the Remnawave Host values
├── docker-compose.yml                  # node nginx + decoy (host networking)
├── Makefile
├── .env.example
└── docs/
    ├── remnawave.md                    # panel / node / profile / host / subscription
    └── yandex-cdn.md                   # Yandex Cloud CDN walkthrough
```

`scripts/setup.sh` renders the `*.template` files into `build/` with your real
domains, path, and mode. There is **no UUID here** — the panel issues those per
user. `build/` and `.env` are git-ignored.

## Prerequisites

- A running **Remnawave panel** and a **remnawave-node** on the node host (the
  origin the CDN pulls from). See [Remnawave docs](https://remna.st/) and
  [docs/remnawave.md](docs/remnawave.md).
- A [Yandex Cloud](https://yandex.cloud/) account with the CDN provider enabled
  (Terraform or `yc` CLI).
- `XRAY_DOMAIN` (the CDN hostname) and a separate `ORIGIN_DOMAIN` DNS record +
  certificate for the node.
- Docker + Docker Compose on the node for the nginx + decoy stack.

## Quick start

On the **node** (which already runs remnawave-node):

```bash
# 1. Configure
cp .env.example .env
$EDITOR .env                 # set XRAY_DOMAIN (CDN) and ORIGIN_DOMAIN (node)

# 2. Render the config profile, Host reference, and node nginx config
make setup                   # generates XRAY_PATH, validates JSON

# 3. Provide the node certificate for ORIGIN_DOMAIN
#    (Let's Encrypt / Certificate Manager — see server/nginx/certs/README.md),
#    or for local testing only:
make cert-selfsigned

# 4. Start the node nginx + decoy
make up
make logs
```

In the **panel**:

1. **Config Profiles → Create**, import `build/remnawave/config-profile.json`,
   and assign it to your node. (Path and mode are already filled in.)
2. **Hosts → Create**, link the `VLESS_XHTTP` inbound, and enter the values from
   `make host` (Address = `XRAY_DOMAIN`, SNI/Host = `XRAY_DOMAIN`, Path, mode…).
3. Assign users; they receive a subscription that points at the CDN.

Provision the CDN with the Terraform in `deploy/yandex/` (or the console steps in
[docs/yandex-cdn.md](docs/yandex-cdn.md)), then CNAME `XRAY_DOMAIN` at the CDN.

Full walkthrough: [docs/remnawave.md](docs/remnawave.md).

## XHTTP mode selection

Set `XRAY_MODE` in `.env`, re-run `make setup`, **and** set the same mode on the
Host. The profile inbound and the Host must agree.

| Mode         | Upload style                     | Yandex Cloud CDN                          |
|--------------|----------------------------------|-------------------------------------------|
| `packet-up`  | many short `POST`s               | **recommended** — survives the 5s timeout (default) |
| `auto`       | negotiates per HTTP version      | may fall back to packet-up; test it       |
| `stream-up`  | one long streaming `POST` (h2/h3)| unreliable — long requests get cut at 5s  |
| `stream-one` | single full-duplex request       | **won't work** — CDN buffers / times out  |

## Security notes

- **The path is a shared secret.** Requests to the wrong path get the decoy
  site, not the proxy. `make setup` generates a random `XRAY_PATH`; keep it out
  of version control (`.env` is git-ignored).
- **UUIDs live in the panel**, not in this repo — rotate users there.
- **Lock the node to the CDN.** `ORIGIN_DOMAIN` resolves to the node's real IP,
  so restrict the node firewall on `:443` to Yandex Cloud CDN egress ranges
  (plus your admin IP). Only the CDN should reach nginx.
- **Xray is never exposed directly** — the inbound is on `127.0.0.1:8001`; only
  nginx faces the network, and only on the secret path.
- **nginx owns 443 on the node.** Don't also run a Reality "selfsteal" listener
  on 443 — this setup fronts Xray with nginx, it doesn't put Xray on 443.

## Troubleshooting

- **`504` from the CDN:** the node didn't respond within 5s. Check the node is
  up (`make logs`, node status in the panel), the firewall allows the CDN, and
  the mode is `packet-up`.
- **Decoy loads but the proxy fails:** the path reached nginx but not Xray.
  Confirm `XRAY_PATH` matches in the profile, nginx, and the Host, and that the
  config profile is assigned to the node.
- **Works direct to node, fails via CDN:** ensure the CDN resource has caching
  **disabled** and `POST` in **allowed methods** (`deploy/yandex/` sets both).
- **TLS errors on clients:** the Host `SNI` must equal `XRAY_DOMAIN`, and the CDN
  edge certificate must cover it.

See [docs/remnawave.md](docs/remnawave.md) and [docs/yandex-cdn.md](docs/yandex-cdn.md).
