# Origin TLS certificate

nginx needs a certificate/key pair here so **Yandex Cloud CDN can reach the
origin over HTTPS**. The CDN connects to your origin by its `ORIGIN_DOMAIN`, so
this certificate must be valid for that hostname. Put two files here:

```
origin.crt   # certificate (PEM, fullchain)
origin.key   # private key  (PEM)
```

These files are git-ignored — keep your private key out of version control.

> Two certificates, two hops. This one secures **CDN → origin** and must be
> valid for `ORIGIN_DOMAIN`. The **visitor → CDN** certificate (for
> `XRAY_DOMAIN`) is issued and renewed by the CDN itself and never lives here —
> see `deploy/yandex/` and `docs/yandex-cdn.md`.

## Option A — Let's Encrypt for the origin hostname (recommended)

Issue a publicly-trusted certificate for `ORIGIN_DOMAIN` directly on the origin
with certbot or acme.sh, then copy the fullchain and key here:

```bash
# example with acme.sh
acme.sh --issue -d node.example.com --standalone
cp ~/.acme.sh/node.example.com_ecc/fullchain.cer server/nginx/certs/origin.crt
cp ~/.acme.sh/node.example.com_ecc/node.example.com.key server/nginx/certs/origin.key
```

A real certificate matters here: Yandex Cloud CDN connects to the origin over
HTTPS and a public CA chain avoids trust problems on the CDN → origin hop.

## Option B — Yandex Certificate Manager

If you manage the origin domain in Yandex Cloud, issue a Let's Encrypt
certificate in **Certificate Manager** for `ORIGIN_DOMAIN`, then export the
chain and private key and drop them here as `origin.crt` / `origin.key`.

## Option C — Self-signed (local testing only)

```bash
make cert-selfsigned
```

This generates a self-signed `origin.crt` / `origin.key` for `ORIGIN_DOMAIN`.
Use it only for local `curl`/loopback testing — Yandex Cloud CDN will not trust
a self-signed origin certificate over an HTTPS origin connection.
